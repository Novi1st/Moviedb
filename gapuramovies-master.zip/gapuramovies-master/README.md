# Dicoding-CatalogueMovie
Memiliki fitur :
1. Popular movies 
2. Upcoming movies
3. Now Playing movies
4. Search movies
5. Lokalisasi bahasa (Inggris dan Indonesia)
6. Popular, upcoming, now playing mengikuti wilayah sesuai bahasa yang dipilih
7. Menyimpan film favorit menggunakan sqlite database
8. Membuat module baru untuk menampilkan daftar film favorit dari sqlite database
9. Stack Widget yang menampilkan poster film favorit
10. Notifikasi reminder harian
11. Notifikasi film rilis hari ini
12. Keep data saat orientation change

Semua data film diambil dari API themoviedb.org.

Projek untuk kelas Menjadi Android Developer Expert (MADE)
